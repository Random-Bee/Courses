#include "types.h"
#include "user.h"
#include "date.h"

// array for month number and the corresponding months
static char(*month_name[]) = {
    [1] "January",
    [2] "February",
    [3] "March",
    [4] "April",
    [5] "May",
    [6] "June",
    [7] "July",
    [8] "August",
    [9] "September",
    [11] "October",
    [12] "November",
    [13] "December",
};

int main(int argc, char *argv[])
{
    struct rtcdate r;

    if (mydate(&r))
    {
        printf(2, "date failed\n");
        exit();
    }

    //  Print date and time in required format
    printf(1, "Year: %d\n", r.year);
    printf(1, "Month: %d or %s\n", r.month, month_name[r.month]);
    printf(1, "Date: %d\n", r.day);
    printf(1, "Hour: %d\n", r.hour);
    printf(1, "Minute: %d\n", r.minute);
    printf(1, "Second: %d\n", r.second);

    exit();
}
