#include "types.h"
#include "user.h"

int arr[3000];
int main(void)
{   
    int pid;
    
    pid = fork();
    if (pid==0) {
        for(int i=0; i<100; i++) arr[i] = i;
        // print page directory infortion after process has write access. At this instance w-bit is 1.
        mypgtPrint();
    }
    else {
        wait();
    }
    
    exit();
}