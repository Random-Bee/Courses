#include "types.h"
#include "user.h"

// uncomment for global array experiment
// int arr[10000];

int main(void)
{

    // uncomment for local array experiment. Modifying and accessing array value to avoid compiler error
    // int arr[10000]
    // arr[0] = 0;
    // printf(1, "%d\n", arr[0]);

    mypgtPrint();
    exit();
}